<html>
<head>
<title>Prova download di file</title>
</head>
<body>
<div align="center">
<p>&nbsp;</p>
<a href="getfile.php?<?php echo "name=contaclick"; ?>">Scarica Contaclick.zip</a> (download <?php @include("count/contaclick.txt"); ?>, size <?php
$dim = @filesize ("contaclick.zip") / 1024;
$dim = round($dim);
echo $dim . 'KB';
?>)
<p>&nbsp;</p>
<p>&nbsp;</p>
<b><a href="http://www.spacemarc.it" target="_blank">Script scaricato da Spacemarc.it</a></b>
</div>
</body>
</html>